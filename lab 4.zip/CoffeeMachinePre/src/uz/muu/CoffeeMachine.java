package uz.muu;

public class CoffeeMachine {

    public void addCoffee(String name, double price, double coffeeAmount, double milkAmount, double waterAmount) {
    }

    public double getPrice(String coffeeName) {
        return 0.0;
    }

    public void rechargeCard(int cardId, double credit) {

    }

    public double getCredit(int cardId) {
        return 0.0;
    }

    public int sell(String coffeeName, int cardId) {
        return 0;
    }

    public void refillProduct(String productName, int amount) {
    }

    public boolean availableCoffee(String coffeeName) {
        return false;
    }

    public double availableProduct(String productName) {
        return -1;
    }
}
